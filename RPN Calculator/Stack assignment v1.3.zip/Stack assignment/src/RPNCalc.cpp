#include "RPNCalc.h"

RPNCalc::RPNCalc()
{

}

RPNCalc::~RPNCalc()
{
    //dtor
}

int performEquation(char c, RPNCalc &calc)
{
    float result;
    float v[2];
    calc.checkEmpty();

    v[0] = calc.pop();
    v[1] = calc.pop();

    switch (c){

    case '+': result = v[0] + v[1];
              break;

    case '-': result = v[0] - v[1];
              break;

    case '*': result = v[0] * v[1];
              break;

    case '/': result = v[0] / v[1];
              break;

    case '^': result = pow(v[0], v[1]);
              break;

    }

    calc.push(result);
    return result;

}

int performTrigFunction(char c, RPNCalc &calc)
{
    float result;
    float deg;
    calc.checkEmpty();

    deg = calc.pop();

    switch (c) {

        case 's': sin(deg);
                  break;

        case 'c': cos(deg);
                  break;

        case 't': tan(deg);
                  break;
    }

    calc.push(result);
    return result;


}
