#ifndef RPNCALC_H
#define RPNCALC_H

#include <Stack.h>
#include <math.h>

class RPNCalc : public Stack
{
    public:
        RPNCalc();
        int performEquation(char c, RPNCalc &calc);
        int performTrigFunction(char c, RPNCalc &calc);
        virtual ~RPNCalc();

    protected:

    private:
};

#endif // RPNCALC_H
