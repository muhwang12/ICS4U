#include <iostream>
#include <Stack.h>
#include <RPNCalc.h>
#include <cstdlib>
#include <apstring.h>
#include <apstring.cpp>

using namespace std;

int main()
{

    RPNCalc calculator;
    apstring equation;
    float temp;

    cout << "Enter your equation (RPN): ";
    cin >> equation;
    cout << equation;
    for(int i = 0; i < equation.length(); i++){
            if(equation[i] < '0' || equation[i] > '9'){
                    if (equation[i] == 's' || equation[i] == 's' || equation[i] == 's'){
                       cout << calculator.performTrigFunction(equation[i], calculator);
                    }
                    else if(calculator.returnValue(i) > 0 && calculator.returnValue(i-1) > 0){
                       cout << calculator.performEquation(equation[i], calculator);
                    }

            }
            else {
                temp = atof(equation.substr(i, 1).c_str());
                calculator.checkEmpty();
                calculator.push(temp);
            }

    }



    return 0;
}


