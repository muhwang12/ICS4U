#include <iostream>
#include <Stack.h>
#include <RPNCalc.h>
#include <cstdlib>
#include <apstring.h>
#include <apstring.cpp>

int main()
{

    RPNCalc Calc;
    apstring equation;
    char currentOp;

    cout << "Enter your equation (RPN): ";
    cin >> equation;
    for(int i = 0; i < equation.length(); i++){
            if(equation[i].c_str() < 48){

            }
            else {
                Calc.push(atof(equation[i].c_str()));
            }
    }

    return 0;
}

