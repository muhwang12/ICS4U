#include "RPNCalc.h"

RPNCalc::RPNCalc()
{
    //ctor
}

RPNCalc::~RPNCalc()
{
    //dtor
}

int performEquation(char c)
{
    switch (c){

    case '+': return push(pop() + pop());

    case '-': return push(pop() - pop());

    case '*': return push(pop() * pop());

    case '/': return push()(pop() / pop());




    }

}
