#ifndef STACK_H
#define STACK_H
#include <iostream>

using namespace std;

class Stack
{
    public:
        Stack();
        void push(float num);
        float pop();
        void checkEmpty();
        float returnValue(int position){return values[position];}
        virtual ~Stack();


    protected:
        float values[20];
        int top;
        bool isEmpty;

    private:


};

#endif // STACK_H
