#ifndef BUTTON_H
#define BUTTON_H

#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_native_dialog.h>
#include <allegro5/allegro_primitives.h>

#define BLACK al_map_rgb(0, 0, 0);
#define SLATEGRAY   al_map_rgb(112,128,144);
#define WHITE al_map_rgb(255, 255, 255);
extern ALLEGRO_FONT font;

class Button
{
    public:
        Button();
        Button(float x, float y, float w, float h, int n) {xcoord = x; ycoord = y; width = w; height = h; num = n;}
        void click() {isClicked = true;}
        void notClick() {isClicked = false;}
        virtual ~Button();

    protected:
        bool isClicked;
        float xcoord, float ycoord, float width, float height;
        int num;

    private:
};

#endif // BUTTON_H
