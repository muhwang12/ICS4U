#include "RPNCalc.h"

RPNCalc::RPNCalc()
{
    isNegative = false;
}

RPNCalc::~RPNCalc()
{
    //dtor
}

//Performs basic operations on numbers in stack based on input
float RPNCalc::performEquation(char c)
{
    float result;
    float v[2];

    v[0] = pop();
    v[1] = pop();

    switch (c){

        case '+': result = v[0] + v[1];
                  break;

        case '-': result = v[0] - v[1];
                  break;

        case '*': result = v[0] * v[1];
                  break;

        case '/': result = v[0] / v[1];
                  break;

        case '^': result = pow(v[0], v[1]);
                  break;

    }

    push(result);
    return result;

} // end-of-function performEquation

//Performs trigonometric functions on the degrees inserted
float RPNCalc::performTrigFunction(char c)
{
    float result;
    float deg;
    checkEmpty();

    deg = pop();

    switch (c) {

        case 's': sin(deg);
                  break;

        case 'c': cos(deg);
                  break;

        case 't': tan(deg);
                  break;
    }

    push(result);
    return result;


} // end-of-function performTrigFunction

//Changes number from positive to negative or vice versa
float RPNCalc::Negation()
{
    push(pop() * -1);
    isNegative = !isNegative;

} // end-of-function Negation


