#include "Button.h"

Button::Button()
{
    isClicked = false;
}

Button::~Button()
{
    //dtor
}

bool Button::checkClick(float x, float y)
{

    if (x > xcoord && x < xcoord + width
        && y > ycoord && y < ycoord + height){

                return true;

    }
    else {

                return false;

    }

} //end-of-function checkClick

void Button::printButton()
{
    al_draw_filled_rounded_rectangle(xcoord, ycoord, xcoord + width, ycoord + height, 3, 3, BLACK);
}

void Button::OperandText()
{
    char calcNum;
    itoa(i, calcNum, num);
    al_draw_text(font, WHITE, xcoord + (width/2), ycoord + (height/2), 0, calcNum);
}

void Button::OpFunction(char op[])
{
    al_draw_text(font, WHITE, xcoord + (width/2), ycoord + (height/2), 0, op[]);
}



