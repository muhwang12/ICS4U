#include "Button.h"


Button::Button()
{
    init_font();
    buttonUse = buttonFunction(position);
    isClicked = false;
}

Button::~Button()
{
    //dtor
}

bool Button::checkClick(float x, float y)
{

    if (x > xcoord && x < xcoord + width
        && y > ycoord && y < ycoord + height){
                return true;
    }
    else {

                return false;

    }

} //end-of-function checkClick

bool Button::init_font()
{
    al_init();
    al_init_font_addon(); // initialize the font addon
	al_init_ttf_addon(); // initialize the ttf (True Type Font) addon
	font = al_load_ttf_font("font.ttf", 30, 0);
	if (!font) {
		std::cerr << "fatal error: could not load 'font.ttf'" << std::endl;
		return false;
	}
	return true;

}//end-of-function init_font

void Button::printButtonLine()
{
    for (int i = 0; i < 4; i++){
            al_draw_line(0, 136 + 68*i, 640, 136 + 68*i, WHITE, 1);
    }
    for (int i = 0; i < 4 i++){

    }
}//end-of-function printButtonLine

apstring Button::buttonFunction(int pos)
{
    apmatrix<apstring> functions {"sin", "cos", "tan", "Pi", "+",
                                  "1", "2", "3", "Sqrt", "-",
                                  "4", "5", "6", "x^y", "*",
                                  "7", "8", "9", "+/-", "/",
                                  ".", "0", "Clr", "Ent", "="};


    for(int i = 0; i < 5; i++){
        for (int j = 0; j < 5; j++){
            if(pos == j + i*5){
                return functions[i][j];
            }
        }
    }
}
//end-of-function buttonFunction

void Button::OperandText()
{

    char calcNum[1];
    //atoi()
    al_draw_text(font, WHITE, xcoord + (width/2), ycoord + (height/2), 0, calcNum);
    al_destroy_font(font);
}//end-of-function OperandText

void Button::OpFunction(char op[])
{
    al_draw_text(font, WHITE, xcoord + (width/2), ycoord + (height/2), 0, op);
    al_destroy_font(font);
}//end-of-function OpFunction



