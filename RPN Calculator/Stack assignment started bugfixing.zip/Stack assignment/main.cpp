#include <iostream>
#include <Stack.h>
#include <RPNCalc.h>
#include <cstdlib>
#include <apstring.h>
#include <apstring.cpp>
#include <math.h>
#include <Button.h>
#include <allegro5/allegro.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_native_dialog.h>
#include <allegro5/allegro_primitives.h>

#define BLACK al_map_rgb(0, 0, 0)
#define WHITE al_map_rgb(255, 255, 255)
#define SLATEGRAY   al_map_rgb(112,128,144)

using namespace std;
const float FPS = 60;
const int SCREEN_W = 640;       // screen width
const int SCREEN_H = 480;       // screen height
ALLEGRO_DISPLAY *screen = NULL;
ALLEGRO_BITMAP *button_bitmap[25] = {NULL};
ALLEGRO_TIMER *timer = NULL;
ALLEGRO_EVENT_QUEUE *event_queue = NULL;
ALLEGRO_FONT *displayFont = NULL;
ALLEGRO_FONT *buttonFont = NULL;
ALLEGRO_TIMEOUT timeout;
ALLEGRO_EVENT ev;
bool quit = false;

bool init_all();
void drawCalc(string &expression, float result);
float compute(char equation[]);
void destroy_all();
void buttonLabel(Button b[], int pos);
void redraw(ALLEGRO_BITMAP *bitmap, string output);

int main()
{
        string expression;
        float finalNum = 0;


        while(!quit){

            drawCalc(expression, finalNum);

            char inputExpression[20];
            for(int i = 0; i < expression.length(); i++){
                inputExpression[i] = expression[i];
            }
            finalNum = compute(inputExpression);
            cout << " = " << finalNum << endl;
            expression = "";
        }

    return 0;
}
bool init_all()
{
    if(!al_init()) {
      cerr << "failed to initialize allegro!" << endl;
      return false;
    }

    if(!al_install_mouse()) {
      cerr << "failed to initialize the mouse!" << endl;
      return false;
    }

   timer = al_create_timer(1.0 / FPS);
   if(!timer) {
      cerr << "failed to create timer" << endl;
      return false;
   }

   screen = al_create_display(SCREEN_W, SCREEN_H);
    if(!screen) {
      cerr << "failed to create screen!" << endl;
      return false;
    }

    al_init_font_addon(); // initialize the font addon
    al_init_ttf_addon(); // initialize the ttf (True Type Font) addon

    displayFont = al_load_ttf_font("font.ttf", 30, 0);
	if (!displayFont) {
		cerr << "fatal error: could not load 'font.ttf'" << endl;
		return false;
	}

	buttonFont = al_load_ttf_font("font.ttf", 20, 0);
	if (!buttonFont) {
		cerr << "fatal error: could not load 'font.ttf'" << endl;
		return false;
	}

	event_queue = al_create_event_queue();
    if(!event_queue) {
      cerr << "failed to create event_queue!" << endl;
      al_destroy_display(screen);
      return false;
    }

	return true;
}

void destroy_all() {
    al_destroy_display(screen);
    al_destroy_event_queue(event_queue);
}

void drawCalc(string &expression, float result)
{
    init_all();
    Button button[25];
    bool op = false;
    int clickedButton = 0;
    string num = "";
    ALLEGRO_BITMAP *display_bitmap = nullptr;


    for(int i = 0; i < 5; i++){
        for(int j = 0; j < 5; j++){
            button[i*5 + j].setProperties(0 + 128*j, 136 + 68*i, 128, 68, j + i*5);
            buttonLabel(button, i*5 + j);
            button_bitmap[j + i*5] = al_create_bitmap(128, 68);

            if (!button_bitmap[i*5 + j]){
                cerr << "failed to create button bitmap!";
                al_destroy_display(screen);
            }

            al_set_target_bitmap (button_bitmap[j + i*5]);
            if((i*5 + j) % 2 == 0)
            al_clear_to_color(WHITE);
            else
            al_clear_to_color(SLATEGRAY);

            }
        }

    //Creates the screen display where numbers are outputted
    display_bitmap = al_create_bitmap(640, 136);
    al_set_target_bitmap(display_bitmap);

    if (!display_bitmap){
        cerr << "failed to create display bitmap!" << endl;
        al_destroy_display (screen);
    }

    al_draw_bitmap(display_bitmap, 0, 0, 0);
    al_set_target_bitmap(al_get_backbuffer(screen));

    al_register_event_source(event_queue, al_get_timer_event_source(timer));
    al_register_event_source(event_queue, al_get_display_event_source(screen));
    al_register_event_source(event_queue, al_get_mouse_event_source());

    al_init_timeout(&timeout, 0.02);

    al_start_timer(timer);

    bool get_event = al_wait_for_event_until(event_queue, &ev, &timeout);

    //Draws the screen display at the top of the calculator
    al_draw_bitmap(display_bitmap, 0, 0, 0);
    al_draw_textf(displayFont, WHITE, SCREEN_W - 20,
    button[0].getY()/2, ALLEGRO_ALIGN_RIGHT, (to_string(result)).c_str());


    while(!op) {
            al_flip_display();
            for (int i = 0; i < 25; i++) {
                al_draw_bitmap(button_bitmap[i],
                               button[i].getX(),
                               button[i].getY(), 0);
            }
            for (int i = 0; i < 25; i++){
                al_draw_textf(buttonFont, BLACK, button[i].getX() + button[i].getW()/2,
                              button[i].getY() + button[i].getH()/2,
                              ALLEGRO_ALIGN_CENTRE, button[i].getLabel().c_str());
            }
            al_wait_for_event(event_queue, &ev);
            if (get_event && ev.type == ALLEGRO_EVENT_DISPLAY_CLOSE){
                al_destroy_display(screen);
                al_destroy_event_queue (event_queue);

            }
            else if (ev.type == ALLEGRO_EVENT_MOUSE_BUTTON_DOWN){
                for(int i = 0; i < 25; i++){
                        if(button[i].checkClick(ev.mouse.x, ev.mouse.y)){
                            cout << "Test";
                            clickedButton = i;
                            if(clickedButton > 4 && clickedButton < 21 &&
                                clickedButton != 9 && clickedButton != 13 &&
                                clickedButton != 14 && clickedButton != 18 && clickedButton != 19){

                                //When "." is pressed without another number being pressed first
                                if (clickedButton == 20 && num == ""){
                                    num += "0";
                                    num += button[i].getLabel();
                                }

                                switch (clickedButton) {

                                //When Pi is pressed
                                case 8: num = "3.14159";
                                        break;

                                //When the +/- button is pressed
                                case 18: if (num != "")
                                         num = to_string(stof(num) * -1);
                                         break;

                                //When clear is pressed
                                case 21: num = "0";
                                         break;

                                default: num += button[i].getLabel();
                                         cout << "Testerino";
                                         break;
                                }

                                redraw(display_bitmap, num);

                            }
                            //When Enter is pressed
                            else if(clickedButton == 23){

                                //adds the number to the output string
                                if (num != "")
                                expression += num + " ";
                                //clears number
                                num = "";

                                redraw(display_bitmap, num);
                            }
                             //when they press exit
                            else if (clickedButton == 23){
                                destroy_all();
                                op = true;
                                quit = true;
                            }
                            //when they press an operation (like *)
                            else {
                                expression += button[i].getLabel();
                                op = true;
                            }



                        }
                }
                al_flip_display();

            }

        }
}

float compute(char equation[])
{
        Stack inputValues;
        RPNCalc calculator;
        apstring input;
        float temp;
        int digits = 0;

        while (true){
            bool decimal = false;
            int pos = 0;
            char *ptr;

            ptr = strtok(equation, " ");
            while (ptr != NULL){

                input = ptr;
                for(int i = 0; i < input.length(); i++){

                        if (input[i] == '.')
                            decimal = true;

                        else if (calculator.gettopValue() == 1 && digits == 0 && (input[i] == 's' || input[i] == 'c' || input[i] == 't'))
                                return calculator.performTrigFunction(input[i]);

                        else if (calculator.gettopValue() == 1 && digits == 0 && input[i] == 'r')
                                return calculator.SquareRoot();

                        else if(calculator.gettopValue() == 2 && digits == 0 && (input[i] < '0' || input[i] > '9')){

                                if (input[i] == '+' || input[i] == '-' || input[i] == '*'|| input[i] == '/'){
                                    cout << calculator.getValue(calculator.gettopValue()-1) << " " << input[i] << " " << calculator.getValue(calculator.gettopValue());
                                    return calculator.performEquation(input[i]);
                                    }
                                else if (input[i] == '^'){
                                    cout << calculator.getValue(calculator.gettopValue()-1) << " ^ " << calculator.getValue(calculator.gettopValue());
                                    return calculator.Exp();
                                    }
                                else {
                                    cout << "Error";
                                    break;
                                    }

                            }

                        else if (input[i] >= '0' || input[i] <= '9'){
                                temp = atof(input.substr(i, 1).c_str());
                                inputValues.checkEmpty();
                                inputValues.push(temp);
                                digits++;

                                if (decimal)
                                pos--;
                            }

                        else {
                            cout << "Invalid Equation";
                            break;
                            }

                    }

                if(digits == input.length() || (decimal && digits == input.length() - 1)){
                    float finalNumber = 0;
                    while (digits != 0){
                        if(pos == 0)
                        finalNumber += inputValues.pop();

                        else
                        finalNumber += inputValues.pop() * (pow(10, pos));

                        pos++;
                        digits--;
                    }
                    calculator.push(finalNumber);
                }

                ptr = strtok(NULL, " ");
            }
        }


}

void buttonLabel(Button b[], int pos)
{

    string label[25] {"sin", "cos", "tan", "Sqrt", "+",
                          "1", "2", "3", "Pi", "-",
                          "4", "5", "6", "x^y", "*",
                          "7", "8", "9", "+/-", "/",
                          ".", "0", "Clr", "Ent", "Exit"};

            b[pos].setLabel(label[pos]);

}

void redraw(ALLEGRO_BITMAP *bitmap, string output)
{
    al_flip_display();
    //Draws output screen
    al_draw_bitmap(bitmap, 0, 0, 0);
    //Prints the number to the display screen
    al_draw_textf(displayFont, WHITE, SCREEN_W - 20,
    68, ALLEGRO_ALIGN_RIGHT, output.c_str());

}


