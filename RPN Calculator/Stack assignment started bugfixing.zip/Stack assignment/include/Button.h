#ifndef BUTTON_H
#define BUTTON_H

#include <iostream>
#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_native_dialog.h>
#include <allegro5/allegro_primitives.h>
#include <allegro5/allegro_font.h>
#include <apstring.h>
#include <iostream>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>
#include <apmatrix.h>
#include <string>

#define BLACK al_map_rgb(0, 0, 0)
#define SLATEGRAY   al_map_rgb(112,128,144)
#define WHITE al_map_rgb(255, 255, 255)


class Button
{
    public:
        Button();
        void setProperties(int x, int y, int w, int h, int p) {xcoord = x; ycoord = y; width = w; height = h; position = p;}
        void printButtonLine();
        void setLabel(std::string s) {buttonUse = s;}
        float getX() {return xcoord;}
        float getY() {return ycoord;}
        float getW() {return width;}
        float getH() {return height;}
        std::string getLabel() {return buttonUse;}
        void click() {isClicked = true;}
        void notClick() {isClicked = false;}
        //bool init_font();
        //void printButton();
        //void OperandText();
        //void OpFunction(char op[]);
        bool checkClick(float x, float y);
        virtual ~Button();

    protected:
        bool isClicked;
        int xcoord, ycoord, width, height;
        int position;
        std::string buttonUse;

    private:

};

#endif // BUTTON_H
