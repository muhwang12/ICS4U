#include "RPNCalc.h"

RPNCalc::RPNCalc()
{

}

RPNCalc::~RPNCalc()
{
    //dtor
}

float RPNCalc::performEquation(char c)
{
    float result;
    float v[2];

    v[0] = pop();
    v[1] = pop();

    switch (c){

        case '+': result = v[0] + v[1];
                  break;

        case '-': result = v[0] - v[1];
                  break;

        case '*': result = v[0] * v[1];
                  break;

        case '/': result = v[0] / v[1];
                  break;

        case '^': result = pow(v[0], v[1]);
                  break;

    }

    push(result);
    return result;

}

float RPNCalc::performTrigFunction(char c)
{
    float result;
    float deg;
    checkEmpty();

    deg = pop();

    switch (c) {

        case 's': sin(deg);
                  break;

        case 'c': cos(deg);
                  break;

        case 't': tan(deg);
                  break;
    }

    push(result);
    return result;


}
