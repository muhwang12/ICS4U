#include "Button.h"

Button::Button(int width, int height)
{
    isClicked = false;
}


Button::~Button()
{
    //dtor
}
