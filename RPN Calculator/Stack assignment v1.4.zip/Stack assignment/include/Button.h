#ifndef BUTTON_H
#define BUTTON_H

#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_native_dialog.h>
#include <allegro5/allegro_primitives.h>



class Button
{
    public:
        Button();
        void click() {isClicked = true;}
        void notClick() {isClicked = false;}
        virtual ~Button();

    protected:
        bool isClicked;
    private:
};

#endif // BUTTON_H
