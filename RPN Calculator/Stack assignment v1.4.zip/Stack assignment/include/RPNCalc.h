#ifndef RPNCALC_H
#define RPNCALC_H

#include <Stack.h>
#include <math.h>

class RPNCalc : public Stack
{
    public:
        RPNCalc();
        float performEquation(char c);
        float performTrigFunction(char c);
        virtual ~RPNCalc();

    protected:

    private:
};

#endif // RPNCALC_H
