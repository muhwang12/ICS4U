#include <iostream>
#include <Stack.h>
#include <RPNCalc.h>
#include <cstdlib>
#include <apstring.h>
#include <apstring.cpp>
#include <Button.h>
#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_native_dialog.h>
#include <allegro5/allegro_primitives.h>

using namespace std;
const int SCREEN_W = 640;       // screen width
const int SCREEN_H = 480;       // screen height

int init_all();

int main()
{

    init_all();
    RPNCalc calculator;
    apstring equation;
    float temp;
    bool off  = false;
    ALLEGRO_EVENT ev;
    Button buttons[20];

    while (!off){


        cout << "Enter your equation (RPN): ";
        cin >> equation;
        cout << equation << endl;
        for(int i = 0; i < equation.length(); i++){
                if(equation[i] < '0' || equation[i] > '9'){
                        if (equation[i] == 's' || equation[i] == 'c' || equation[i] == 't'){
                           float answer = calculator.performTrigFunction(equation[i]);
                        }
                        else {
                           cout << calculator.returnValue(calculator.returntopValue()) << " " << equation[i] << " " << calculator.returnValue(calculator.returntopValue()-1);
                           float answer = calculator.performEquation(equation[i]);
                           cout << " = " << answer << endl;
                        }

                }
                else {
                    temp = atof(equation.substr(i, 1).c_str());
                    calculator.checkEmpty();
                    calculator.push(temp);
                }

        }
    }



    return 0;
}

int init_all(){

    ALLEGRO_DISPLAY *display = nullptr;
	ALLEGRO_EVENT_QUEUE *event_queue = nullptr;		// add event queue object

	// Initialize Allegro
	al_init();

	// initialize display
	display = al_create_display(SCREEN_W, SCREEN_H);
	if (!display) {
    	al_show_native_message_box(display, "Error", "Error", "Failed to initialize display!",
                                 nullptr, ALLEGRO_MESSAGEBOX_ERROR);
       	return -1;
	}
	al_set_window_title(display, "RPN Calculator");

   	// Initialize mouse routines
	if (!al_install_mouse()) {
	    al_show_native_message_box(display, "Error", "Error", "failed to initialize the mouse!",
                                 nullptr, ALLEGRO_MESSAGEBOX_ERROR);
      	return -1;
   	}


	// need to add image processor
 	if (!al_init_image_addon()) {
    	al_show_native_message_box(display, "Error", "Error",
    		"Failed to initialize al_init_image_addon!",nullptr, ALLEGRO_MESSAGEBOX_ERROR);
    	return 0;
	}

	// set up event queue
	event_queue = al_create_event_queue();
	if (!event_queue) {
		al_show_native_message_box(display, "Error", "Error", "Failed to create event_queue!",
                                 nullptr, ALLEGRO_MESSAGEBOX_ERROR);
		al_destroy_display(display);
      	return -1;
	}

	// need to register events for our event queue
	al_register_event_source(event_queue, al_get_display_event_source(display));
}

