#ifndef BUTTON_H
#define BUTTON_H

#include <iostream>
#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_native_dialog.h>
#include <allegro5/allegro_primitives.h>
#include <allegro5/allegro_font.h>
#include <iostream>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>
#include <apmatrix.h>

#define BLACK al_map_rgb(0, 0, 0)
#define SLATEGRAY   al_map_rgb(112,128,144)
#define WHITE al_map_rgb(255, 255, 255)



class Button
{
    public:
        Button();
        Button(float x, float y, float w, float h, int p) {xcoord = x; ycoord = y; width = w; height = h; position = p;}
        int returnDigit() {return num;}
        float returnX() {return xcoord;}
        float returnY() {return ycoord;}
        void click() {isClicked = true;}
        void notClick() {isClicked = false;}
        bool init_font();
        void printButton();
        void OperandText();
        void OpFunction(char op[]);
        bool checkClick(float x, float y);
        virtual ~Button();

    protected:
        bool isClicked;
        float xcoord, ycoord, width, height;
        int position;

    private:
        ALLEGRO_FONT *font = nullptr;
};

#endif // BUTTON_H
