#ifndef RPNCALC_H
#define RPNCALC_H

#include <Stack.h>
#include <math.h>

class RPNCalc : public Stack
{
    public:
        RPNCalc();
        float performEquation(char c);
        float performTrigFunction(char c);
        float Exp();
        float Swap();
        float SquareRoot();
        float Pi() {return 3.14159;}
        virtual ~RPNCalc();

    protected:
        bool isNegative;

    private:
};

#endif // RPNCALC_H
