#include "RPNCalc.h"

RPNCalc::RPNCalc()
{
    isNegative = false;
}

RPNCalc::~RPNCalc()
{
    //dtor
}

//Performs basic operations on numbers in stack based on input
float RPNCalc::performEquation(char c)
{
    float result;
    float v[2];

    v[0] = pop();
    v[1] = pop();

    switch (c){

        case '+': result = v[1] + v[0];
                  break;

        case '-': result = v[1] - v[0];
                  break;

        case '*': result = v[1] * v[0];
                  break;

        case '/': result = v[1] / v[0];
                  break;

        default:  cout << "Invalid Operator";

    }

    push(result);
    return result;

} // end-of-function performEquation

//Performs trigonometric functions on the degrees inserted
float RPNCalc::performTrigFunction(char c)
{
    float result;
    float deg;
    checkEmpty();

    deg = pop() * Pi() / 180;

    switch (c) {

        case 's': result = sin(deg);
                  break;

        case 'c': result = cos(deg);
                  break;

        case 't': result = tan(deg);
                  break;

        default: cout << "Invalid Trigonometric Function";
    }

    push(result);
    return result;


} // end-of-function performTrigFunction

//Changes number from positive to negative or vice versa
float RPNCalc::Negation()
{
    push(pop() * -1);
    isNegative = !isNegative;

} // end-of-function Negation

//Exponent Method
float RPNCalc::Exp()
{
    float result;
    float v[2];

    v[0] = pop();
    v[1] = pop();

    result = pow(v[1], v[0]);
} // end-of-function Exp

