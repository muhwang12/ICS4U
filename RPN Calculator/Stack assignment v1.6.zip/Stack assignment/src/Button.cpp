#include "Button.h"
#include <iostream>
#include <allegro5/allegro_font.h>

Button::Button()
{
    isClicked = false;
}

Button::~Button()
{
    //dtor
}

bool Button::checkClick(float x, float y)
{

    if (x > xcoord && x < xcoord + width
        && y > ycoord && y < ycoord + height){

                return true;

    }
    else {

                return false;

    }

} //end-of-function checkClick

/*bool Button::init_font()
{
    al_init();
    al_init_font_addon(); // initialize the font addon
	al_init_ttf_addon(); // initialize the ttf (True Type Font) addon

	font = al_load_ttf_font("font.ttf", 30, 0);

	if (!font) {
		cerr << "fatal error: could not load 'font.ttf'" << endl;
		return false;
	}
	return true;
}*/

/*void Button::printButton()
{
    al_draw_filled_rounded_rectangle(xcoord, ycoord, xcoord + width, ycoord + height, 3, 3, BLACK);
}

void Button::OperandText()
{
    init_font();
    char calcNum[1];
    itoa(num, calcNum, 10);
    al_draw_text(font, WHITE, xcoord + (width/2), ycoord + (height/2), 0, calcNum);
    al_destroy_font(font);
}

void Button::OpFunction(char op[])
{
    init_font();
    al_draw_text(font, WHITE, xcoord + (width/2), ycoord + (height/2), 0, op[]);
    al_destroy_font(font);
}*/



