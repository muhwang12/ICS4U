#include <iostream>
#include <Stack.h>
#include <RPNCalc.h>
#include <cstdlib>
#include <apstring.h>
#include <apstring.cpp>
#include <math.h>
//#include <Button.h>
#include <allegro5/allegro.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_native_dialog.h>
#include <allegro5/allegro_primitives.h>

using namespace std;
const int SCREEN_W = 640;       // screen width
const int SCREEN_H = 480;       // screen height


int main()
{
    Stack inputValues;
    RPNCalc calculator;
    char equation[20];
    float temp;
    bool off = false;
    //Button button[20];
    ALLEGRO_DISPLAY *display = NULL;
    ALLEGRO_EVENT_QUEUE *event_queue = NULL;

    /*
   if(!al_init()) {
      fprintf(stderr, "failed to initialize allegro!\n");
      return -1;
   }

   if(!al_install_mouse()) {
      fprintf(stderr, "failed to initialize the mouse!\n");
      return -1;
   }

   display = al_create_display(SCREEN_W, SCREEN_H);
   if(!display) {
      fprintf(stderr, "failed to create display!\n");
      return -1;
   }

   al_set_target_bitmap(al_get_backbuffer(display));

   event_queue = al_create_event_queue();
   if(!event_queue) {
      fprintf(stderr, "failed to create event_queue!\n");
      al_destroy_display(display);
      return -1;
   }

    al_register_event_source(event_queue, al_get_display_event_source(display));

    al_register_event_source(event_queue, al_get_timer_event_source(timer));

    al_register_event_source(event_queue, al_get_mouse_event_source());

    al_flip_display();

    while (true){
        ALLEGRO_EVENT ev;
        al_wait_for_event(event_queue, &ev);

        if (ev.type == ALLEGRO_MOUSE_BUTTON_DOWN){

        }
        char holder[1];
        for (int i = 0; i < 10; i++){
            if(button[i].checkClick()){
                itoa(button.returnDigit(), holder, 10);
                equation += holder;
            }
        }
        */
        int digits = 0;
        float answer = 0;
        apstring token;
        cout << "Enter your equation (RPN): ";
        while(true){

            cin >> equation;
            char *ptr;
            ptr = strtok(equation, " ");
            while (ptr != NULL)
            {
                    token = ptr;
                    for(int i = 0; i < token.length(); i++){
                        if(token[i] < '0' || token[i] > '9'){
                                if (token[i] == 's' || token[i] == 'c' || token[i] == 't'){
                                    switch (token[i]){

                                        case 's': cout << "sin(" << calculator.returnValue(calculator.returntopValue()) << ")";
                                                  break;

                                        case 'c': cout << "cos(" << calculator.returnValue(calculator.returntopValue()) << ")";
                                                  break;

                                        case 't': cout << "tan(" << calculator.returnValue(calculator.returntopValue()) << ")";
                                                  break;

                                        default: cout << "Invalid Selection";
                                                 break;

                                    }

                                   answer = calculator.performTrigFunction(token[i]);
                                   cout << " = " << answer << endl;
                                }
                                else if (token[i] == '+' || token[i] == '-' || token[i] == '*'|| token[i] == '/'){
                                   cout << calculator.returnValue(calculator.returntopValue()-1) << " " << token[i] << " " << calculator.returnValue(calculator.returntopValue());
                                   answer = calculator.performEquation(token[i]);
                                   cout << " = " << answer << endl;
                                }
                                else if (token[i] == '^'){
                                   cout << calculator.returnValue(calculator.returntopValue()-1) << " ^ " << calculator.returnValue(calculator.returntopValue());
                                   answer = calculator.Exp();
                                   cout << " = " << answer << endl;
                                }
                                else {
                                    cout << "Error";
                                    break;
                                }

                        }
                        else {
                            temp = atof(token.substr(i, 1).c_str());
                            inputValues.checkEmpty();
                            inputValues.push(temp);
                            digits++;
                            //cout << "digits while entering: " << digits << endl;
                        }
                }

                if(digits == token.length()){
                            cout << "hi";
                            float finalNumber = inputValues.pop();
                            int pos = 1;
                            digits--;
                            while (digits != 0){
                                finalNumber += inputValues.pop() * (pow(10, pos));
                                //cout << finalNumber << endl;
                                pos++;
                                digits--;
                                //cout << "digits while adding up numbers: " << digits << endl;
                            }
                            calculator.push(finalNumber);
                        }
                else if (digits >= 1) {
                    cout << "Invalid";
                }

                ptr = strtok(NULL, " ");
            }

        }
    //}


    return 0;
}





