#ifndef STACK_H
#define STACK_H
#include <iostream>

using namespace std;

class Stack
{
    public:
        Stack();
        void push(char c);
        char pop();
        void checkEmpty();
        char returnValue(int position){return values[position]};
        virtual ~Stack();


    protected:

    private:
        bool isEmpty;
        float values[20];
        int top;
};

#endif // STACK_H
