#ifndef RPNCALC_H
#define RPNCALC_H

#include <Stack.h>


class RPNCalc : public Stack
{
    public:
        RPNCalc();
        virtual ~RPNCalc();

    protected:

    private:
};

#endif // RPNCALC_H
