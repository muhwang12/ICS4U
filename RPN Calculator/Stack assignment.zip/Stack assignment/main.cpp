#include <iostream>
#include <Stack.h>
#include <apstring.h>

int main()
{
    Stack Hi;
    apstring Test;

    cin >> Test;
    Hi.push(Test[0]);
    cout << Hi.returnValue(0);

    return 0;
}
