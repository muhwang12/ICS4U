#include <iostream>
#include <Stack.h>
#include <apstring.h>
#include <apstring.cpp>

int main()
{
    Stack Hi;
    apstring Test;

    cin >> Test;
    Hi.push(Test[0]);
    cout << Hi.returnValue(0);

    return 0;
}
