#include "Stack.h"

Stack::Stack()
{
    top = -1;
    char values[20] = "";
    isEmpty = true;
}


void Stack::push(char c)
{
        top++;
        values[top] = c;
}

char Stack::pop()
{
    if (!isEmpty){
    char c = values[top];
    top--;
    return c;
    }
    else {
        cout << "Error: Stack is empty.";
    }
}

void Stack::checkEmpty()
{
    if (top < 0)
    isEmpty = true;
    else
    isEmpty = false;
}


Stack::~Stack()
{
    //dtor
}
