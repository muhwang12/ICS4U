#include "Stack.h"

Stack::Stack()
{
    top = -1;
    values[20] = "";
    isEmpty = true;
}


void Stack::push(float num)
{
        top++;
        values[top] = num;
}

float Stack::pop()
{
    if (!isEmpty){
    float num = values[top];
    top--;
    return num;
    }
    else {
        cout << "Error: Stack is empty.";
    }
}

void Stack::checkEmpty()
{
    if (top < 0)
    isEmpty = true;
    else
    isEmpty = false;
}


Stack::~Stack()
{
    //dtor
}
