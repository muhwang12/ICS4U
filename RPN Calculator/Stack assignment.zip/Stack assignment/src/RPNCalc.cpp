#include "RPNCalc.h"

RPNCalc::RPNCalc()
{
    //ctor
}

RPNCalc::~RPNCalc()
{
    //dtor
}

int performEquation(char c)
{
    switch (c){

    case '+': return RPNCalc.pop() + RPNCalc.pop();

    case '-': return push(RPNCalc.pop() - RPNCalc.pop());

    case '*': return push(RPNCalc.pop() * RPNCalc.pop());

    case '/': return push()(RPNCalc.pop() / RPNCalc.pop());




    }

}
