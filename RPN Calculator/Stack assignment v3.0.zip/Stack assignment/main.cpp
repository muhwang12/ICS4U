/*****************************************************************************
 *	Name: Matthew Wang                                                       *
 *	Course: ICS4U                                                            *
 *	Date: November 3, 2017                                                   *
 *	                                                                         *
 *	Purpose: Creates a calculator that utilizes Reverse Polish Notation (RPN)*
 *           to do calculations.                                             *
 *	                                                                         *
 *	Usage:                                                                   *
 *	                                                                         *
 *	Revision History:                                                        *
 *	                                                                         *
 *	Known Issues:                                                            *
 *	                                                                         *
 *****************************************************************************/

#include <iostream>
#include <Stack.h>
#include <RPNCalc.h>
#include <cstdlib>
#include <math.h>
#include <Button.h>
#include <allegro5/allegro.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>

#define BLACK al_map_rgb(0, 0, 0)
#define WHITE al_map_rgb(255, 255, 255)
#define SLATEGRAY   al_map_rgb(112,128,144)

using namespace std;
const float FPS = 60;
const int SCREEN_W = 640;       // screen width
const int SCREEN_H = 480;       // screen height
ALLEGRO_DISPLAY *screen = NULL;
ALLEGRO_BITMAP *button_bitmap[25] = {NULL};
ALLEGRO_TIMER *timer = NULL;
ALLEGRO_EVENT_QUEUE *event_queue = NULL;
ALLEGRO_FONT *displayFont = NULL;
ALLEGRO_FONT *buttonFont = NULL;
ALLEGRO_TIMEOUT timeout;
ALLEGRO_EVENT ev;
bool quit = false;

bool init_all();
void createCalc(string &expression, float result);
float compute(string equation);
void destroy_all();
void buttonLabel(Button b[], int pos);
void drawButton(Button b[]);

int main()
{
        if(!init_all())
        return 1;

        string expression;
        float finalNum = 0;

        while(!quit){
            createCalc(expression, finalNum);
            finalNum = compute(expression);
            cout << " = " << finalNum << endl;
        }

    return 0;
}
//Initializes allegro routines and screen
bool init_all()
{
    if(!al_init()) {
      cerr << "failed to initialize allegro!" << endl;
      return false;
    }

    if(!al_install_mouse()) {
      cerr << "failed to initialize the mouse!" << endl;
      return false;
    }

   timer = al_create_timer(1.0 / FPS);
   if(!timer) {
      cerr << "failed to create timer" << endl;
      return false;
   }

   screen = al_create_display(SCREEN_W, SCREEN_H);
    if(!screen) {
      cerr << "failed to create screen!" << endl;
      return false;
    }

    al_init_font_addon(); // initialize the font addon
    al_init_ttf_addon(); // initialize the ttf (True Type Font) addon

    displayFont = al_load_ttf_font("font.ttf", 30, 0);
	if (!displayFont) {
		cerr << "fatal error: could not load 'font.ttf'" << endl;
		return false;
	}

	buttonFont = al_load_ttf_font("font.ttf", 20, 0);
	if (!buttonFont) {
		cerr << "fatal error: could not load 'font.ttf'" << endl;
		return false;
	}

	event_queue = al_create_event_queue();
    if(!event_queue) {
      cerr << "failed to create event_queue!" << endl;
      al_destroy_display(screen);
      return false;
    }

	return true;
}

//Destroys display and event queue
void destroy_all() {
    al_destroy_display(screen);
    al_destroy_event_queue(event_queue);
}

//Creates calculator
void createCalc(string &expression, float result)
{
    bool decimal = false;
    Button button[25];
    bool op = false;
    int fullNumCounter = 0;
    int clickedButton = 0;
    string num = "";
    string preventError;
    int decimalZeros = 0;
    ALLEGRO_BITMAP *display_bitmap = nullptr;

    //Initializes buttons
    for(int i = 0; i < 5; i++){
        for(int j = 0; j < 5; j++){
            button[i*5 + j].setProperties(0 + 128*j, 136 + 68*i, 128, 68, j + i*5);
            buttonLabel(button, i*5 + j);
            button_bitmap[j + i*5] = al_create_bitmap(128, 68);

            if (!button_bitmap[i*5 + j]){
                cerr << "failed to create button bitmap!";
                al_destroy_display(screen);
            }

            al_set_target_bitmap (button_bitmap[j + i*5]);
            if((i*5 + j) % 2 == 0)
            al_clear_to_color(WHITE);
            else
            al_clear_to_color(SLATEGRAY);

            }
        }

    //Creates the screen display where numbers are outputted
    display_bitmap = al_create_bitmap(640, 136);
    al_set_target_bitmap(display_bitmap);
    al_clear_to_color(BLACK);
    if (!display_bitmap){
        cerr << "failed to create display bitmap!" << endl;
        al_destroy_display (screen);
    }

    al_set_target_bitmap(al_get_backbuffer(screen));

    //Registers events
    al_register_event_source(event_queue, al_get_timer_event_source(timer));
    al_register_event_source(event_queue, al_get_display_event_source(screen));
    al_register_event_source(event_queue, al_get_mouse_event_source());

    al_start_timer(timer);

    al_init_timeout(&timeout, 0.02);

    //Draws the screen display at the top of the calculator
    al_draw_bitmap(display_bitmap, 0, 0, 0);
    al_draw_textf(displayFont, WHITE, SCREEN_W - 20,
    button[0].getY()/2, ALLEGRO_ALIGN_RIGHT, (to_string(result)).c_str());
    drawButton(button);
    al_flip_display();

    expression = "";
    //Loops until operator or function has been pressed
    while(!op) {
            //After clearing, All Clear (AC) is there for clearing both numbers
            if(num == "0")
                button[22].setLabel("AC");
            else
                button[22].setLabel("Clr");

            drawButton(button);
            al_flip_display();

            al_init_timeout (&timeout, 0.2);

            // Tells computer to look for an event
            bool get_event = al_wait_for_event_until(event_queue, &ev, &timeout);

            if (get_event && ev.type == ALLEGRO_EVENT_DISPLAY_CLOSE){
                al_destroy_display(screen);
                al_destroy_event_queue (event_queue);

            }
            else if (ev.type == ALLEGRO_EVENT_MOUSE_BUTTON_DOWN){
                for(int i = 0; i < 25; i++){
                    if(button[i].checkClick(ev.mouse.x, ev.mouse.y)){

                        clickedButton = i;
                        if(clickedButton > 4 && clickedButton < 23 &&
                            clickedButton != 9 && clickedButton != 13 &&
                                clickedButton != 14 && clickedButton != 19){

                                if(fullNumCounter == 2 && clickedButton != 22)
                                    break;

                                //Draws output screen
                                al_draw_bitmap(display_bitmap, 0, 0, 0);

                                switch (clickedButton) {

                                    //When Pi is pressed
                                    case 8: num = "3.14159";
                                            break;

                                    //When the +/- button is pressed
                                    case 18: if (num != "")
                                                num = to_string(stof(num) * -1);
                                             break;

                                    //When "." is pressed
                                    case 20: if (!decimal){
                                                //When "." is pressed without another number being pressed first
                                                if(num == "")
                                                    num += "0";

                                                preventError = num;
                                                num += button[i].getLabel();
                                                decimal = true;


                                             } break;

                                    //When clear is pressed (When AC, clears everything in output string)
                                    case 22: if (button[22].getLabel() == "AC"){
                                                expression = "";
                                                fullNumCounter = 0;
                                                decimal = false;
                                             }
                                             num = "0";
                                             break;

                                    default: if (num == "0")
                                                num = button[i].getLabel();
                                             //Tracks for unnecessary zeros
                                             else if (decimal && clickedButton == 21){
                                                decimalZeros++;
                                                num += button[i].getLabel();
                                             }
                                             else
                                                num += button[i].getLabel();
                                             break;
                                    }

                                //Prints out the updated number
                                if(num != ""){
                                al_draw_textf(displayFont, WHITE, SCREEN_W - 20,
                                68, ALLEGRO_ALIGN_RIGHT, num.c_str());
                                }


                            }
                        //When x^y is pressed
                        else if (clickedButton == 13){

                            if (fullNumCounter == 2){
                                expression += "^";
                                op = true;
                            }
                            else
                                cout << "Invalid Button Press" << endl;


                        }

                        //When Enter is pressed
                        else if(clickedButton == 23){

                            //Adds the number to the output string
                                //Prevents hanging decimal points and their subsequent zeros from affecting output
                                if(num.find('.') == num.length()- 1 - decimalZeros){
                                    //Removes unnecessary decimal points
                                    num = preventError;

                                    expression += num + " ";
                                    num = "";
                                    fullNumCounter++;

                                    cout << "Number Entered" << endl;
                                }
                                else if (num != ""){
                                    expression += num + " ";
                                    num = "";
                                    fullNumCounter++;

                                    cout << "Number Entered" << endl;
                                }
                                else
                                    cout << "Invalid Button Press" << endl;

                        }
                        //Exits program when Exit button is pressed
                        else if (clickedButton == 24){
                            op = true;
                            quit = true;
                            destroy_all();

                            cout << "Program Exited" << endl;
                        }
                        //When a one numbered function (trigonometric or square root) is pressed
                        else if (clickedButton < 4) {

                            if(fullNumCounter == 1){
                                expression += button[i].getLabel();
                                op = true;
                            }
                            else
                                cout << "Invalid Button Press" << endl;

                        }
                        //When an operation button is pressed
                        else {

                            if (fullNumCounter == 2){
                                expression += button[i].getLabel();
                                op = true;
                            }
                            else
                                cout << "Invalid Button Press" << endl;

                        }

                   }
              }

            al_flip_display();

        }

    }

}

//Performs equation on expression contained in the string provided
float compute(string equation)
{
        Stack inputValues;
        RPNCalc calculator;
        string input;
        char *eq = &equation[0u];
        float temp;
        int digits = 0;
        bool negative = false;

        //Loop keeps going until a final number is returned
        while (true){
            bool decimal = false;

            char *ptr;

            //Parses individual characters from string of
            //of blocks of operand(s) and their operator
            ptr = strtok(eq, " ");
            while (ptr != NULL){

                int pos = 0;
                input = ptr;
                for(int i = 0; i < input.length(); i++){

                        if (input[i] == '.')
                            decimal = true;

                        //If there's a negative number
                        else if(input[i] == '-' && input.length() > 1)
                            negative = true;

                        //If a trigonometric function is chosen
                        else if (calculator.gettopValue() == 1 && digits == 0 && (input[i] == 's' || input[i] == 'c' || input[i] == 't'))
                                return calculator.performTrigFunction(input[i]);

                        //If the square root function is chosen
                        else if (calculator.gettopValue() == 1 && digits == 0 && input[i] == 'r')
                                return calculator.SquareRoot();

                        //If a basic operator or the exponent function is chosen
                        else if(calculator.gettopValue() == 2 && digits == 0 && (input[i] < '0' || input[i] > '9')){

                                //Basic operator calculation
                                if (input[i] == '+' || input[i] == '-' || input[i] == '*'|| input[i] == '/'){
                                    cout << calculator.getValue(calculator.gettopValue()-1) << " " << input[i] << " " << calculator.getValue(calculator.gettopValue());
                                    return calculator.performEquation(input[i]);
                                }
                                //Exponent function calculation
                                else if (input[i] == '^'){
                                    cout << calculator.getValue(calculator.gettopValue()-1) << " ^ " << calculator.getValue(calculator.gettopValue());
                                    return calculator.Exp();
                                }
                                else {
                                    cout << "Error";
                                    break;
                                }

                            }
                        //Puts numbers in a temporary stack
                        else if (input[i] >= '0' || input[i] <= '9'){
                                temp = atof(input.substr(i, 1).c_str());
                                inputValues.checkEmpty();
                                inputValues.push(temp);
                                digits++;

                                if (decimal)
                                pos--;
                            }

                        else {
                            cout << "Invalid Equation";
                            break;
                            }

                    }

                //Takes numbers from a temporary stack and parses it into a float
                if(digits == input.length() || (decimal && digits == input.length() - 1)){
                    float finalNumber = 0;
                    //Uses position in number to add that digit to the final number
                    while (digits != 0){

                        //Exception for ones
                        if(pos == 0)
                            finalNumber += inputValues.pop();

                        else
                            finalNumber += inputValues.pop() * (pow(10, pos));

                        pos++;
                        digits--;
                    }
                    if(negative){
                        calculator.push(finalNumber * -1);
                        negative = false;
                    }
                    else
                        calculator.push(finalNumber);

                    decimal = false;
                }
                //Moves on to next block of character(s)
                ptr = strtok(NULL, " ");
            }
        }

}

//Labels buttons based on their position
void buttonLabel(Button b[], int pos)
{

    string label[25] {"sin", "cos", "tan", "Sqrt", "+",
                          "1", "2", "3", "Pi", "-",
                          "4", "5", "6", "x^y", "*",
                          "7", "8", "9", "+/-", "/",
                          ".", "0", "Clr", "Ent", "Exit"};

            b[pos].setLabel(label[pos]);

}

//Draws buttons on screen
void drawButton(Button b[])
{

    for (int i = 0; i < 25; i++){
                al_draw_bitmap(button_bitmap[i],
                               b[i].getX(),
                               b[i].getY(), 0);

                al_draw_textf(buttonFont, BLACK, b[i].getX() + b[i].getW()/2,
                              b[i].getY() + b[i].getH()/2,
                              ALLEGRO_ALIGN_CENTRE, b[i].getLabel().c_str());
            }
}


