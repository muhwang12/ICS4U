#include "Button.h"


Button::Button()
{
    //init_font();
    isClicked = false;
}

Button::~Button()
{
    //dtor
}

//Checks for location of mouse at the time of clicking
bool Button::checkClick(float x, float y)
{

    if (x > xcoord && x < xcoord + width
        && y > ycoord && y < ycoord + height){
                return true;
    }
    else {
                return false;
    }

} //end-of-function checkClick

