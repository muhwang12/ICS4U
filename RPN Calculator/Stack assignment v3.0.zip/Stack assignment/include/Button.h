#ifndef BUTTON_H
#define BUTTON_H

#include <iostream>

class Button
{
    public:
        Button();
        //Modifiers
        void setProperties(int x, int y, int w, int h, int p) {xcoord = x; ycoord = y; width = w; height = h; position = p;}
        void setLabel(std::string s) {buttonUse = s;}

        //Accessors
        float getX() {return xcoord;}
        float getY() {return ycoord;}
        float getW() {return width;}
        float getH() {return height;}
        std::string getLabel() {return buttonUse;}

        void printButtonLine();
        void click() {isClicked = true;}
        void notClick() {isClicked = false;}
        bool checkClick(float x, float y);
        virtual ~Button();

    protected:
        bool isClicked;
        int xcoord, ycoord, width, height;
        int position;
        std::string buttonUse;

    private:

};

#endif // BUTTON_H
