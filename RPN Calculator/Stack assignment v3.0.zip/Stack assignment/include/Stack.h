#ifndef STACK_H
#define STACK_H

#include <iostream>

using namespace std;

class Stack
{
    public:
        Stack();
        void push(float num);
        float pop();
        void checkEmpty();
        float getValue(int position){return values[position];}
        float gettopValue(){return top;}
        virtual ~Stack();


    protected:
        float values[50];
        int top;
        bool isEmpty;

    private:


};

#endif // STACK_H
